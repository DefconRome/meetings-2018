#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

void disable_buffering()
{
	// avoid buffering issues - you can ignore this
	setvbuf(stdin, 0, _IONBF, 0);
	setvbuf(stdout, 0, _IONBF, 0);
}

void spawn_shell()
{
	char *argv[] = {"/bin/sh", 0};
	execve(argv[0], argv, 0);
}

int main()
{
	char buffer[32], *password;

	disable_buffering();

	printf("Enter password: ");
	scanf("%s", buffer); // i'm blue da ba dee da ba dye, da ba dee da ba dye
	
	if (!(password = getenv("REMOTE_SHELL_PASSWORD"))) {
		printf("ERROR: password not set!\n");
		return 1;
	}

	if (!strcmp(buffer, password))
		spawn_shell();
	else
		printf("Access denied!\n");

	return 0;
}
