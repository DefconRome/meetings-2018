import angr
# load the example
project = angr.Project("./foo")

# start a new SimulationManager
simgr = project.factory.simulation_manager()
# step
simgr.step()
# step until it branches
simgr.run(until=lambda sm: len(sm.active) != 1)
# check the states that are still active
print (simgr.active)
